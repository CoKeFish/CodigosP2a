
#include "ADC_int.h"
#include "UART_int.h"
#include "Timer_int.h"


/**
 * @brief Variable global externa, indica TS = N*100uS, donde N es PERIOD
 */
uint16_t PERIOD = 2;