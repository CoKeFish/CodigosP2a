//
// Created by rrtc26 on 27/03/2023.
//

#ifndef PRUEBAS_IIR_H
#define PRUEBAS_IIR_H

double IIR(double input);
unsigned int FilterIIR(double input);

#endif //PRUEBAS_IIR_H
