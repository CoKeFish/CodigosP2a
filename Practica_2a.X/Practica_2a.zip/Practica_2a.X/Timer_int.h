

#include "mcc_generated_files/adc/adcc.h"

void Timer_int(void);